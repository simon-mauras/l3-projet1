javac GrandNombre.java
javac ArbreBinaire.java
javac Test.java
java Test

javac HuffmanTree.java
javac Huffman.java
java Huffman text.in > text.out
java Huffman text2.in > text2.out