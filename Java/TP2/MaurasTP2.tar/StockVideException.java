public class StockVideException extends Exception {
    public StockVideException() {
	System.out.println("Il n'y a pas assez de livres en stock !");
    }
}
