public class Point {
    
    private double x, y;

    public Point() {
	this.x = 0;
	this.y = 0;
    }
    
    public Point(double _x, double _y) {
	this.x = _x;
	this.y = _y;
    }

    public void setCoords(double _x, double _y) {
	this.x = _x;
	this.y = _y;
    }

    public double getX() {
	return this.x;
    }
    
    public double getY() {
	return this.y;
    }
}