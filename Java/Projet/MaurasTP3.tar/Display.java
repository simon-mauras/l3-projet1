import java.awt.Graphics;
import javax.swing.JPanel;
import java.awt.Color;

public class Display extends JPanel {
    
    private Diagram diag;
    private double scale;
    private double x0;
    private double y0;

    public Display() {
	super();
	scale = 1;
	x0 = 0;
	y0 = 0;
    }
    
    public void paintComponent(Graphics g) {
	g.setColor(Color.RED);
	for (int i=0; i<diag.centers.length; i++) {
	    double x = this.getWidth()/2 + scale * (diag.centers[i].getX() - x0);
	    double y = this.getHeight()/2 - scale * (diag.centers[i].getY() - y0);
	    g.drawOval((int)x-3, (int)y-3, 6, 6);
	}
	g.setColor(Color.BLACK);
	for (int i=0; i<diag.points.length; i++) {
	    double x = this.getWidth()/2 + scale * (diag.points[i].getX() - x0);
	    double y = this.getHeight()/2 - scale * (diag.points[i].getY() - y0);
	    g.drawLine((int)x-2, (int)y-2, (int)x+2, (int)y+2);
	    g.drawLine((int)x+2, (int)y-2, (int)x-2, (int)y+2);
	}
	g.setColor(Color.RED);
	if (diag.centers.length > 0) {
	    for (int i=0; i<diag.points.length; i++) {
		double dMin = Double.POSITIVE_INFINITY;
		int ind = -1;
		for (int j=0; j<diag.centers.length; j++) {
		    double d = (diag.centers[j].getX() - diag.points[i].getX())
			* (diag.centers[j].getX() - diag.points[i].getX())
			+ (diag.centers[j].getY() - diag.points[i].getY())
			* (diag.centers[j].getY() - diag.points[i].getY());
		    if (d < dMin) {
			ind = j;
			dMin = d;
		    }
		}
		double xa = this.getWidth()/2 + scale*(diag.points[i].getX() - x0);
		double ya = this.getHeight()/2 - scale*(diag.points[i].getY() - y0);
		double xb = this.getWidth()/2 + scale*(diag.centers[ind].getX() - x0);
		double yb = this.getHeight()/2 - scale*(diag.centers[ind].getY() - y0);
		g.drawLine((int)xa, (int)ya, (int)xb, (int)yb);
	    }
	}
    }

    public void setDiagram(Diagram d) {
	diag = d;
    }
}