import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.util.Random;

public class Diagram {

    public Point[] points;
    public Point[] centers;

    public Diagram() {
	points = new Point[0];
	centers = new Point[0];
    }
    
    public void loadFile(File f) {
	try {
	    Scanner sc = new Scanner(f);
	    int n = sc.nextInt();
	    Point[] tmp = new Point[n];
	    for (int i=0; i<n; i++)
		tmp[i] = new Point(sc.nextInt(), sc.nextInt());
	    sc.close();
	    points = tmp;
	} catch (IOException e) {
	    System.out.println("Erreur...\n");
	}
    }
    
    public void chooseCenters(int k) {
	if (k > points.length)
	    k = points.length;
	Point tmp[] = new Point[points.length];
	for (int i=0; i<points.length; i++)
	    tmp[i] = points[i];

	Random rand = new Random();
	for (int i=0; i<tmp.length; i++) {
	    int ind = i + rand.nextInt(tmp.length - i);
	    if (0 > ind || ind >= tmp.length)
		System.out.println(ind);
	    Point p = tmp[i];
	    tmp[i] = tmp[ind];
	    tmp[ind] = p;
	}

	centers = new Point[k];
	for (int i=0; i<k; i++)
	    centers[i] = new Point(tmp[i].getX(), tmp[i].getY());
    }

    public double kMeansIteration() {
	int nb[] = new int[centers.length];
	double sumX[] = new double[centers.length];
	double sumY[] = new double[centers.length];

	for (int j=0; j<centers.length; j++) {
	    nb[j] = 0;
	    sumX[j] = sumY[j] = 0;
	}

	for (int i=0; i<points.length; i++) {
	    double minDist = Double.POSITIVE_INFINITY;
	    int ind = -1;
	    for (int j=0; j<centers.length; j++) {
		double d = (points[i].getX() - centers[j].getX())
		    * (points[i].getX() - centers[j].getX())
		    + (points[i].getY() - centers[j].getY())
		    * (points[i].getY() - centers[j].getY());
		if (d < minDist) {
		    minDist = d;
		    ind = j;
		}
	    }
	    nb[ind]++;
	    sumX[ind] += points[i].getX();
	    sumY[ind] += points[i].getY();
	}
	
	double res = 0;
	for (int j=0; j<centers.length; j++) {
	    double x = sumX[j] / (double)nb[j];
	    double y = sumY[j] / (double)nb[j];
	    double d = (x - centers[j].getX()) * (x - centers[j].getX())
		+ (y - centers[j].getY()) * (y - centers[j].getY());
	    if (d > res)
		res = d;
	    centers[j].setCoords(x, y);
	}

	return Math.sqrt(res);
    }
}

