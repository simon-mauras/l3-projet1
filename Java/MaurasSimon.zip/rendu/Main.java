public class Main {

    public static void main(String[] args) {
	Diagram d = new Diagram();
	Frame f = new Frame();
	f.setDiagram(d);
	f.display();
    }
}
